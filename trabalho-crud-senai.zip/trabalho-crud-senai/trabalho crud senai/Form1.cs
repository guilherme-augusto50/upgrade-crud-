using System.Runtime.InteropServices;

namespace trabalho_crud_senai
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void Cabe�alio_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void Cabe�alio_Paint(object sender, PaintEventArgs e)
        {
            Cabe�alio.Dock = DockStyle.Top;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;

        }

        private void Login_Resize(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txtEmail.Text;
                string senha = txtSenha.Text;

                // Verifica��o de campos obrigat�rios
                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(senha))
                {
                    MessageBox.Show("Preencha todos os campos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Tentando autenticar como funcion�rio
                Funcionarios funcionario = new Funcionarios();
                if (funcionario.Autenticar(email, senha))
                {
                    MessageBox.Show("Login de funcion�rio realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    principalF telaFuncionario = new principalF();
                    telaFuncionario.Show();
                    this.Hide();
                    return;
                }

                // Tentando autenticar como cliente/usu�rio
                usuarios usuario = new usuarios();
                if (usuario.Autenticar(email, senha))
                {
                    MessageBox.Show("Login de cliente realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    telaprincipal telaCliente = new telaprincipal();
                    telaCliente.Show();
                    this.Hide();
                    return;
                }

                // Se nenhum dos dois for v�lido
                MessageBox.Show("Nome, email ou senha inv�lidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar fazer login: " + ex.Message, "Erro - M�todo Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void likCadastro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
            this.Hide();
        }
    }
}
