﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace trabalho_crud_senai
{
    class ConexaoDBcs
    {
        private string servidor = "Server=localhost; Database=lojaDb; Uid=root; Pwd='';";

        public MySqlConnection Conectar()
        {
            MySqlConnection conn = new MySqlConnection(servidor);
            try
            {
                conn.Open();
                Console.WriteLine("Conexão estabelecida com sucesso!");
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Erro ao conectar ao banco de dados: " + ex.Message);
            }
            return conn;
        }
    }
}
